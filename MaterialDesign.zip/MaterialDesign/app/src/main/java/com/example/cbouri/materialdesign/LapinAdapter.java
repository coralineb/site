package com.example.cbouri.materialdesign;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

/**
 * Created by cbouri on 18/10/2017.
 */

public class LapinAdapter extends BaseAdapter {
    // Une liste de personnes
    private ArrayList<Lapin> ListL;

    //Le contexte dans lequel est présent notre adapter
    private Context mContext;

    //Un mécanisme pour gérer l'affichage graphique depuis un layout XML
    private LayoutInflater mInflater;

    public LapinAdapter(Context context, Map<String,?> aListP) {
        mContext = context;
        ListL = PutMapToArrayList(aListP);
        mInflater = LayoutInflater.from(mContext);
    }

    @Override
    public int getCount() {
        return ListL.size();
    }

    @Override
    public Object getItem(int position) {
        return ListL.get(position);
    }


    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LinearLayout layoutItem;
        //(1) : Réutilisation des layouts
        if (convertView == null) {
            //Initialisation de notre item à partir du  layout XML "personne_layout.xml"
            layoutItem = (LinearLayout) mInflater.inflate(R.layout.itemlvlapin, parent, false);
        } else {
            layoutItem = (LinearLayout) convertView;
        }

        //(2) : Récupération des TextView de notre layout
        TextView tvnom = (TextView)layoutItem.findViewById(R.id.tvnom);
        TextView tvdate = (TextView)layoutItem.findViewById(R.id.tvdatenaiss);
        TextView tvcouleur = (TextView)layoutItem.findViewById(R.id.tvcouleur);
        TextView tvsexe = (TextView)layoutItem.findViewById(R.id.tvsexe);

        //(3) : Renseignement des valeurs
        tvnom.setText(ListL.get(position).getNom());
        tvdate.setText(ListL.get(position).getDatenaiss());
        tvcouleur.setText(ListL.get(position).getCouleur());

        //(4) Changement de la couleur du fond de notre item
        if (Objects.equals(ListL.get(position).getSexe(), "F")) {
            tvsexe.setText("Femelle");
        } else {
            tvsexe.setText("Male");
        }

        //On retourne l'item créé.
        return layoutItem;
    }

    public ArrayList<Lapin> PutMapToArrayList(Map<String,?> map)
    {
        ArrayList<Lapin> listLapin=new ArrayList<Lapin>();
        String key;
        Set listKey=map.keySet();
        Iterator it = listKey.iterator();
        while(it.hasNext())
        {
            key=it.next().toString();
            String[] parts = map.get(key).toString().split(";");
            listLapin.add(new Lapin(key,parts[0],parts[1],parts[2]));
        }

        return listLapin;
    }
}
