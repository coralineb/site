package com.example.cbouri.materialdesign;

/**
 * Created by cbouri on 19/10/2017.
 */

public class Fourniture {
    private String marque;
    private int unite;
    private String desc;

    public Fourniture(String marque, int unite, String desc) {
        this.marque = marque;
        this.unite = unite;
        this.desc = desc;
    }

    public Fourniture() {

    }

    public String getMarque() {
        return marque;
    }

    public void setMarque(String marque) {
        this.marque = marque;
    }

    public int getUnite() {
        return unite;
    }

    public void setUnite(int unite) {
        this.unite = unite;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
