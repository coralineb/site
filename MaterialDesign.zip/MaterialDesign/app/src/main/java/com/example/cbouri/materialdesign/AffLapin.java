package com.example.cbouri.materialdesign;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;

/**
 * Created by cbouri on 16/10/2017.
 */

public class AffLapin extends AppCompatActivity {
    Menu m=null;
    // The action Bar
    private ActionBar actionBar;

    // The ToolBar
    private Toolbar toolbar;

    // The menuItem that handles the ActionView
    MenuItem menuItemActionView;

    // The root Layout of the View of the ActionView
    LinearLayout lilActionView;

    // The EditText to listen for the user input
    EditText edtActionView;

    // The searchButton
    ImageButton btnActionView;

    // Boolean to know which version is running
    private boolean postICS,postLollipop;

    SharedPreferences preferences;
    LapinAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lapin);

        // Find the toolbar
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        postICS =getResources().getBoolean(R.bool.postICS);
        postLollipop =getResources().getBoolean(R.bool.postLollipop);

        if(postLollipop) {
            toolbar.setElevation(15);
        }

        // Define the toolbar as the ActionBar
        setSupportActionBar(toolbar);
        actionBar=getSupportActionBar();

        //bouton flottant
        FloatingActionButton fab=(FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), AjoutLapin.class);
                startActivity(intent);
            }
        });


        preferences = getSharedPreferences("LIST_LAPIN",0);
        // Objet permettant d'éditer les SharedPreferences
        SharedPreferences.Editor editor = preferences.edit();
        // Stockage d'une chaîne de caractères
        editor.putString("Lily", "F;24/08/2016;Isabelle");
        editor.putString("Baloo", "F;24/08/2016;Fauve");
        editor.commit();


        //Création et initialisation de l'Adapter pour les personnes
        adapter = new LapinAdapter(this, preferences.getAll());

        //Récupération du composant ListView
        ListView list = (ListView)findViewById(R.id.lvlapin);

        //Initialisation de la liste avec les données
        list.setAdapter(adapter);

    }

    public boolean onCreateOptionsMenu(Menu menu) {

        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menulapin, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected (MenuItem item)
    {
        switch(item.getItemId())
        {
            case R.id.fourniture:
                //Dans le Menu "m", on active tous les items dans le groupe d'identifiant "R.id.group2"
                Intent intent=new Intent(this, AffFourniture.class);
                startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }


}
