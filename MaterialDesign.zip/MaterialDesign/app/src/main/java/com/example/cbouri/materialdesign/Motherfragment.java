package com.example.cbouri.materialdesign;

import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v4.app.ListFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by cbouri on 17/10/2017.
 */

public abstract class Motherfragment extends Fragment {
    ListView gvfour;
    FloatingActionButton fab;
    FournitureAdapter adapter;

    public Motherfragment(){super();}
    /**
     * Called to have the fragment instantiate its user interface view.
     * This is optional, and non-graphical fragments can return null (which
     * is the default implementation).  This will be called between
     * {@link #onCreate(Bundle)} and {@link #onActivityCreated(Bundle)}.
     * <p/>
     * <p>If you return a View from here, you will later be called in
     * {@link #onDestroyView} when the view is being released.
     *
     * @param inflater           The LayoutInflater object that can be used to inflate
     *                           any views in the fragment,
     * @param container          If non-null, this is the parent view that the fragment's
     *                           UI should be attached to.  The fragment should not add the view itself,
     *                           but this can be used to generate the LayoutParams of the view.
     * @param savedInstanceState If non-null, this fragment is being re-constructed
     *                           from a previous saved state as given here.
     * @return Return the View for the fragment's UI, or null.
     */
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View myView=inflater.inflate(R.layout.myfragment,container,false);
        gvfour= (ListView) myView.findViewById(R.id.lvfour);
            //update(myView);
        adapter = new FournitureAdapter(getActivity(), "LIST_GRANULE");
        //Initialisation de la liste avec les données
        //gvfour.setAdapter(adapter);
        //bouton flottant
        fab=(FloatingActionButton) myView.findViewById(R.id.fabfour);
        fab.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                affFenetreAjour("granule","LIST_GRANULE");
            }
        });
        return myView ;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


    }
    protected abstract void update(View myView);

    public void affFenetreAjour(String four, final String nomfic)
    {
        final Fourniture f=new Fourniture();
        // custom dialog
        final Dialog dialog = new Dialog(getActivity());
        dialog.setContentView(R.layout.ajoutfour);
        dialog.setTitle("Ajouter "+four);

        final EditText marque=(EditText) dialog.findViewById(R.id.etmarque);
        final EditText unite=(EditText) dialog.findViewById(R.id.etunite);
        final EditText desc=(EditText) dialog.findViewById(R.id.etdesc);

        Button dialogButton = (Button) dialog.findViewById(R.id.btnaj);
        // if button is clicked, close the custom dialog
        dialogButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();

                SharedPreferences preferences = getContext().getSharedPreferences(nomfic,0);
                // Objet permettant d'éditer les SharedPreferences
                SharedPreferences.Editor editor = preferences.edit();
                // Stockage d'une chaîne de caractères
                editor.putString(marque.getText().toString(), Integer.parseInt(unite.getText().toString())+";"+desc.getText().toString()+";");
                editor.commit();
            }
        });

        dialog.show();
    }

}