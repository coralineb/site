package com.example.cbouri.materialdesign;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;

/**
 * Created by cbouri on 18/10/2017.
 */

public class AjoutLapin extends AppCompatActivity {
    ListView sampleList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ajoutlapin);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
    }

    public void onClickAjoutLapin(View view) {
        EditText ednom=(EditText)findViewById(R.id.etnom);
        EditText eddate=(EditText)findViewById(R.id.etdate);
        EditText edcouleur=(EditText)findViewById(R.id.etcouleur);
        RadioButton F=(RadioButton)findViewById(R.id.rbf);
        RadioButton M=(RadioButton)findViewById(R.id.rbm);
        String sexe="";

        if(F.isChecked())
            sexe="F";
        else
            sexe="M";

        SharedPreferences preferences = getSharedPreferences("LIST_LAPIN",0);
        // Objet permettant d'éditer les SharedPreferences
        SharedPreferences.Editor editor = preferences.edit();
        // Stockage d'une chaîne de caractères
        editor.putString(ednom.getText().toString(), sexe+";"+eddate.getText().toString()+";"+edcouleur.getText().toString());
        editor.commit();
        Intent intent=new Intent(this, Lapin.class);
        startActivity(intent);
    }
}
