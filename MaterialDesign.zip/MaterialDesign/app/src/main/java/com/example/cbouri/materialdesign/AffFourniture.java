package com.example.cbouri.materialdesign;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;

/**
 * Created by cbouri on 17/10/2017.
 */

public class AffFourniture extends AppCompatActivity {
    ListView sampleList;
    Menu m=null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fourniture);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Find the Tab Layout
        TabLayout tabLayout = (TabLayout) findViewById(R.id.tabLayout);

        // Define its gravity and its mode
        tabLayout.setTabGravity(TabLayout.GRAVITY_FILL);
        tabLayout.setTabMode(TabLayout.MODE_SCROLLABLE);//essayer avec fixed

        // Instanciate the PageAdapter
        MyPagerAdapter pagerAdapter=new MyPagerAdapter(this);

        // Define the color to use (depending on the state a different color should be disaplyed)
        // Works only if done before adding tabs
        tabLayout.setTabTextColors(getResources().getColorStateList(R.color.colorAccent));

        // Find the viewPager
        ViewPager viewPager = (ViewPager) super.findViewById(R.id.viewpager);

        // Populate your TabLayout
        tabLayout.addTab(tabLayout.newTab().setText("Granulé"));
        tabLayout.addTab(tabLayout.newTab().setText("Litière"));
        tabLayout.addTab(tabLayout.newTab().setText("Foin"));

        // Add a listener
        tabLayout.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {/*do your navigation*/}
            @Override
            public void onTabUnselected(TabLayout.Tab tab) {/*do nothing*/}
            @Override
            public void onTabReselected(TabLayout.Tab tab) {/*do nothing*/}
        });

        // Affectation de l'adapter au ViewPager
        viewPager.setAdapter(pagerAdapter);
        viewPager.setClipToPadding(false);
        viewPager.setPageMargin(12);


        // AND CLUE TABLAYOUT AND VIEWPAGER
        tabLayout.setupWithViewPager(viewPager);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menufourniture, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected (MenuItem item)
    {
        switch(item.getItemId())
        {
            case R.id.lapin:
                //Dans le Menu "m", on active tous les items dans le groupe d'identifiant "R.id.group2"
                Intent intent=new Intent(this, AffLapin.class);
                startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }

}

