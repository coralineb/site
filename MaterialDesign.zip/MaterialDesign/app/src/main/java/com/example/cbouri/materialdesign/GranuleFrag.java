package com.example.cbouri.materialdesign;

import android.app.Dialog;
import android.content.Intent;
import android.view.View;

/**
 * Created by cbouri on 17/10/2017.
 */

public class GranuleFrag extends Motherfragment{
    public GranuleFrag(){super();}
    @Override
    protected void update(View myView) {
        //Création et initialisation de l'Adapter pour les personnes
        //adapter = new FournitureAdapter(getActivity(), "LIST_GRANULE");



    }

}
