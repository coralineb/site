package com.example.cbouri.materialdesign;

import android.content.SharedPreferences;
import android.view.View;
import android.widget.GridView;
import android.widget.ListView;

/**
 * Created by cbouri on 17/10/2017.
 */

public class FoinFrag extends Motherfragment{

    FournitureAdapter adapter;

    public FoinFrag(){super();}
    @Override
    protected void update(View myView) {
        /*//Création et initialisation de l'Adapter pour les personnes
        FournitureAdapter adapter = new FournitureAdapter(this.getContext(), "LIST_FOIN");

        //Initialisation de la liste avec les données
        gvfour.setAdapter(adapter);*/
    }


}
