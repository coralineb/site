package com.example.cbouri.materialdesign;

/**
 * Created by cbouri on 18/10/2017.
 */

public class Lapin {
    private String nom;
    private String datenaiss;
    private String couleur;
    private String sexe;

    public Lapin(String nom, String sexe, String datenaiss, String couleur) {
        this.nom = nom;
        this.datenaiss = datenaiss;
        this.couleur = couleur;
        this.sexe=sexe;
    }

    public String getSexe() {
        return sexe;
    }

    public void setSexe(String sexe) {
        this.sexe = sexe;
    }

    public Lapin() {

    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getDatenaiss() {
        return datenaiss;
    }

    public void setDatenaiss(String datenaiss) {
        this.datenaiss = datenaiss;
    }

    public String getCouleur() {
        return couleur;
    }

    public void setCouleur(String couleur) {
        this.couleur = couleur;
    }
}
