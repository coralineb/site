package com.example.cbouri.materialdesign;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentPagerAdapter;

import java.util.ArrayList;

/**
 * Created by cbouri on 17/10/2017.
 */

public class MyPagerAdapter extends FragmentPagerAdapter {

    // The list of ordered fragments
    private final ArrayList<Fragment> fragments;

    /***
     * The constructor
     *
     * @param ctx
     *            The Context
     */
    public MyPagerAdapter(AffFourniture ctx) {
        super(ctx.getSupportFragmentManager());
        fragments = new ArrayList();
        // A stuff I never did before, instanciate my fragment
        Fragment frag = new GranuleFrag();
        fragments.add(frag);
        frag = new LitiereFrag();
        fragments.add(frag);
        frag = new FoinFrag();
        fragments.add(frag);
    }

    /**
     * This method may be called by the ViewPager to obtain a title string to
     * describe the specified page. This method may return null indicating no
     * title for this page. The default implementation returns null.
     *
     * @param position
     *            The position of the title requested
     * @return A title for the requested page
     */
    @Override
    public CharSequence getPageTitle(int position) {
        if(position==0)
            return "Granulé";
        else if(position==1)
            return "Litiere";
        else if(position==2)
            return "Foin";
        return "Erreur";
    }

    @Override
    public Fragment getItem(int position) {
        return fragments.get(position);
    }

    @Override
    public int getCount() {
        return 3;
    }
}
