package com.example.cbouri.materialdesign;

import android.view.View;

/**
 * Created by cbouri on 17/10/2017.
 */

public class LitiereFrag extends Motherfragment{
    public LitiereFrag(){super();}
    @Override
    protected void update(View myView) {
        /*//Création et initialisation de l'Adapter pour les personnes
        FournitureAdapter adapter = new FournitureAdapter(this.getContext(), "LIST_LITIERE");

        //Initialisation de la liste avec les données
        gvfour.setAdapter(adapter);*/
    }
}
