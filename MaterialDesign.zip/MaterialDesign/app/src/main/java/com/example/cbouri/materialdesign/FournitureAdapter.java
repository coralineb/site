package com.example.cbouri.materialdesign;

import android.content.Context;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

/**
 * Created by cbouri on 19/10/2017.
 */

public class FournitureAdapter extends BaseAdapter {
    private ArrayList<Fourniture> ListF;

    //Le contexte dans lequel est présent notre adapter
    private Context mContext;

    //Un mécanisme pour gérer l'affichage graphique depuis un layout XML
    private LayoutInflater mInflater;

    public FournitureAdapter(Context context, String nomFic) {
        mContext = context;
        ListF = getAllItem(nomFic);
        mInflater = LayoutInflater.from(mContext);
    }

    public FournitureAdapter(Context context) {
        mContext = context;
        mInflater = LayoutInflater.from(mContext);
    }

    @Override
    public int getCount() {
        return ListF.size();
    }

    @Override
    public Object getItem(int position) {
        return ListF.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LinearLayout layoutItem;
        //(1) : Réutilisation des layouts
        if (convertView == null) {
            //Initialisation de notre item à partir du  layout XML "personne_layout.xml"
            layoutItem = (LinearLayout) mInflater.inflate(R.layout.itemfourniture, parent, false);
        } else {
            layoutItem = (LinearLayout) convertView;
        }

        //(2) : Récupération des TextView de notre layout
        TextView tvmarque = (TextView)layoutItem.findViewById(R.id.tvmarque);
        TextView tvunite = (TextView)layoutItem.findViewById(R.id.tvunité);
        TextView tvdesc = (TextView)layoutItem.findViewById(R.id.tvdesc);


        //(3) : Renseignement des valeurs
        tvmarque.setText(ListF.get(position).getMarque());
        tvunite.setText(ListF.get(position).getUnite());
        tvdesc.setText(ListF.get(position).getDesc());


        //On retourne l'item créé.
        return layoutItem;
    }

    public ArrayList<Fourniture> getAllItem(String nomFic)
    {
        ArrayList<Fourniture> listFour=new ArrayList<Fourniture>();
        String key;
        Map<String,?> map;

        SharedPreferences preferences = mContext.getSharedPreferences(nomFic,0);


        // Objet permettant d'éditer les SharedPreferences
        SharedPreferences.Editor editor = preferences.edit();
        // Stockage d'une chaîne de caractères
        editor.putString("Pasero", "5;Lorem ipsum dolor sit amet, consectetur adipiscing elit");
        editor.putString("Animalis", "5;Lorem ipsum dolor sit amet, consectetur adipiscing elit");
        editor.putString("Oxbow", "5;Lorem ipsum dolor sit amet, consectetur adipiscing elit");
        editor.commit();


        map=preferences.getAll();

        Set listKey=map.keySet();
        Iterator it = listKey.iterator();
        while(it.hasNext())
        {
            key=it.next().toString();
            String[] parts = map.get(key).toString().split(";");
            listFour.add(new Fourniture(key,Integer.parseInt(parts[0]),parts[1]));
        }

        return listFour;
    }
}
