package com.example.cbouri.bunny;

import android.app.Activity;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import io.realm.Realm;
import io.realm.RealmResults;

public class Accueil extends Activity {
    private LapinAdapter adapter;
    private Realm realm;
    private LayoutInflater inflater;
    private RealmController rc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.accueil);

        rc=RealmController.with(this);
        this.realm=rc.getRealm();
        rc.refresh();
        rc.createLapinAleatoire();
        adapter.notifyDataSetChanged();
        rc.createLapinAleatoire();
        adapter.notifyDataSetChanged();

        realm.beginTransaction();
        RealmResults<Lapin> realmlistlapin = rc.getAllLapin();
        ArrayList<Lapin> listlapin=new ArrayList<Lapin>();
        for(int i=0;i<realmlistlapin.size();i++)
        {
            listlapin.add(realmlistlapin.get(i));
        }
        adapter = new LapinAdapter(this, listlapin);
        ListView list = (ListView)findViewById(R.id.lvlapin);
        list.setAdapter(adapter);

    }
}
