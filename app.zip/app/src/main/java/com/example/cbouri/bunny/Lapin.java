package com.example.cbouri.bunny;

import java.util.Date;

import io.realm.RealmObject;
import io.realm.annotations.PrimaryKey;

/**
 * Created by cbouri on 03/10/2017.
 */

public class Lapin extends RealmObject{
    @PrimaryKey
    private int idLapin;
    private String nom;
    private String race;
    private String couleur;
    private Date datenaiss;
    private String sexe;
    private Boolean sterilise;


    public String getNom() {
        return nom;
    }

    public int getIdLapin() {
        return idLapin;
    }

    public void setIdLapin(int idLapin) {
        this.idLapin = idLapin;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getRace() {
        return race;
    }

    public void setRace(String race) {
        this.race = race;
    }

    public String getCouleur() {
        return couleur;
    }

    public void setCouleur(String couleur) {
        this.couleur = couleur;
    }

    public Date getDatenaiss() {
        return datenaiss;
    }

    public void setDatenaiss(Date datenaiss) {
        this.datenaiss = datenaiss;
    }

    public String getSexe() {
        return sexe;
    }

    public void setSexe(String sexe) {
        this.sexe = sexe;
    }

    public Boolean getSterilise() {
        return sterilise;
    }

    public void setSterilise(Boolean sterilise) {
        this.sterilise = sterilise;
    }
}
