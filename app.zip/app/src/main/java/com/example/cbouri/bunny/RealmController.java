package com.example.cbouri.bunny;

import android.app.Activity;
import android.app.Application;
import android.app.Fragment;

import io.realm.Realm;
import io.realm.RealmResults;

/**
 * Created by cbouri on 04/10/2017.
 */

public class RealmController {
    private static RealmController instance;
    private final Realm realm;

    public RealmController(Application application) {
        this.realm = Realm.getDefaultInstance();
    }

    public static RealmController with(Fragment fragment)
    {
        if(instance==null)
        {
            instance=new RealmController(fragment.getActivity().getApplication());
        }
        return instance;
    }

    public static RealmController with(Activity activity)
    {
        if(instance==null)
        {
            instance=new RealmController(activity.getApplication());
        }
        return instance;
    }

    public static RealmController with(Application application)
    {
        if(instance==null)
        {
            instance=new RealmController(application);
        }
        return instance;
    }

    public static RealmController getInstance(){
        return instance;
    }

    public Realm getRealm()
    {
        return realm;
    }

    public void refresh()
    {
        realm.refresh();
    }

    //supprimer toute al classe lapin
    public void clearAllLapin()
    {
        realm.beginTransaction();
        realm.clear(Lapin.class);
        realm.commitTransaction();
    }

    public Lapin getLapin(String id)
    {
        return realm.where(Lapin.class).equalTo("idLapin",id).findFirst();
    }

    public boolean hasLapin()
    {
        return !realm.allObjects(Lapin.class).isEmpty();
    }

    public RealmResults<Lapin> getLapinByNom(String nom)
    {
        return realm.where(Lapin.class).contains("nom",nom).findAll();
    }

    public RealmResults<Lapin> getAllLapin()
    {
        return realm.where(Lapin.class).findAll();
    }

    public void createLapinAleatoire()
    {
        realm.beginTransaction();
        Lapin l=realm.createObject(Lapin.class);
        l.setIdLapin(getNextKey());
        l.setNom("test");

        realm.commitTransaction();
    }

    public int getNextKey() {
        try {
            Number number = realm.where(Lapin.class).max("idLapin");
            if (number != null) {
                return number.intValue() + 1;
            } else {
                return 0;
            }
        } catch (ArrayIndexOutOfBoundsException e) {
            return 0;
        }
    }


}
